#!/bin/sh
#

diff project/doc/README project.OLD/doc/README
diff project/src/lib/lib.c project.OLD/src/lib/lib.c
diff project/src/main/functions.c project.OLD/src/main/functions.c
diff project/src/main/main.c project.OLD/src/main/main.c
diff project/MAKEFILE project.OLD/MAKEFILE
