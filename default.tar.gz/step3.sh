#!/bin/sh
#

rm -rf project.OLD > /dev/null
mv project project.OLD
tar xzvf default.tar.gz > /dev/null
