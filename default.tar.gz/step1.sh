#!/bin/sh
#

cp versions/main.c.1 project/src/main/main.c
cp versions/functions.c.1 project/src/main/functions.c
cp versions/MAKEFILE.0 project/MAKEFILE
