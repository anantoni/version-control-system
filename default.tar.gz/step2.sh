#!/bin/sh
#

cp versions/functions.c.2 project/src/main/functions.c
cp versions/main.c.2 project/src/main/main.c
cp versions/README.1 project/doc/README
