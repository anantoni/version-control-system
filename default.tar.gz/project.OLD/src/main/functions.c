#include "STACK.h"
#include<stdlib.h>


void initStack(struct Stack_t* s){
	s = NULL;
}

struct Stack_t* push(struct Stack_t* s,char *data)
{
	struct Stack_t* tmp = (struct Stack_t*)malloc(sizeof(struct Stack_t));
	if(tmp == NULL){
		// no memory available
		exit(0);
	}
	tmp->data = data;
	tmp->next = s;
	s = tmp;
	return s;
}
