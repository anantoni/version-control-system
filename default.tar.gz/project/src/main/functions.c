#include "STACK.h"
#include<stdlib.h>


void initStack(struct Stack_t* s){
	s = NULL;
}
