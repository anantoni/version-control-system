#!/bin/sh
#

cp versions/functions.c.3 project/src/main/functions.c

